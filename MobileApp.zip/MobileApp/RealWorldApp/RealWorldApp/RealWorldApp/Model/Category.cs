﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RealWorldApp.Model
{
    public class Category
    {
        public int id { get; set; }
        public string type { get; set; }
        public object vehicles { get; set; }
    }
}
