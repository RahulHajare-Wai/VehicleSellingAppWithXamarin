﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RealWorldApp.Model
{
    public class VehicleImage
    {
        public int VehicleId { get; set; }
        public byte[] ImageArray { get; set; }
    }
}
