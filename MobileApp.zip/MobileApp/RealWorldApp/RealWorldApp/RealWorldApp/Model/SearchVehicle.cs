﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RealWorldApp.Model
{
    public class SearchVehicle
    {
        public int id { get; set; }
        public string title { get; set; }
        public string model { get; set; }
        public string company { get; set; }
    }
}
